using System.Collections.Generic;

namespace Testing.Repository.Examples
{
    public class ExampleViewModel
    {
        public IEnumerable<Animal> Results { get; set;}
    }
}