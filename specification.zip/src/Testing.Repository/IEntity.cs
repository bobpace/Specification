namespace Testing.Repository
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}