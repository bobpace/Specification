namespace FubuCore.Configuration
{
    public enum SettingCategory
    {
        environment,
        package,
        core,
        profile
    }
}