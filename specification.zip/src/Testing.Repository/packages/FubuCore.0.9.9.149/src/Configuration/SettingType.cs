﻿namespace FubuCore.Configuration
{
    public enum SettingType
    {
        Required,
        Optional
    }
}