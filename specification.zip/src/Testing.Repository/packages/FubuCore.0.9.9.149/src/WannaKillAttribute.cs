using System;

namespace FubuCore
{
    public class WannaKillAttribute : Attribute
    {
        
    }
}